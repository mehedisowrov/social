<?php
class PDFFB_Shortcodes {
    
    public function __construct() {
        add_shortcode('pdf_flipbook', array($this, 'flipbook_shortcode'));
        add_shortcode('pdf_flipbook_link', array($this, 'flipbook_link_shortcode'));
        add_shortcode('pdf_flipbook_embed', array($this, 'flipbook_embed_shortcode'));
        
        // Auto-link PDFs in content
        add_filter('the_content', array('PDFFB_Processor', 'auto_link_pdfs'));
    }
    
    public function flipbook_shortcode($atts) {
        $atts = shortcode_atts(array(
            'url' => '',
            'width' => '100%',
            'height' => '600px',
            'flip_sound' => 'true',
            'toolbar_position' => 'top',
            // ... other params
        ), $atts);
        
        if (empty($atts['url'])) {
            return '<p>Please provide a PDF URL</p>';
        }
        
        return PDFFB_Processor::generate_flipbook($atts['url'], $atts);
    }
    
    public function flipbook_link_shortcode($atts) {
        $atts = shortcode_atts(array(
            'url' => '',
            'text' => 'View PDF',
            'image' => '',
            'class' => ''
        ), $atts);
        
        if (empty($atts['url'])) {
            return '';
        }
        
        if (!empty($atts['image'])) {
            return '<a href="' . esc_url($atts['url']) . '" class="pdf-flipbook-link ' . esc_attr($atts['class']) . '" data-flipbook="1"><img src="' . esc_url($atts['image']) . '" alt="' . esc_attr($atts['text']) . '"></a>';
        }
        
        return '<a href="' . esc_url($atts['url']) . '" class="pdf-flipbook-link ' . esc_attr($atts['class']) . '" data-flipbook="1">' . esc_html($atts['text']) . '</a>';
    }
    
    public function flipbook_embed_shortcode($atts) {
        // Similar to flipbook_shortcode but with different default options
    }
}