<?php
class PDFFB_Processor {
    
    public static function generate_flipbook($pdf_url, $options = array()) {
        // Default options
        $defaults = array(
            'flip_sound' => true,
            'toolbar_position' => 'top',
            'enable_download' => true,
            'enable_print' => true,
            // ... other defaults
        );
        
        $options = wp_parse_args($options, $defaults);
        
        // Generate unique ID for this instance
        $instance_id = 'pdf-flipbook-' . md5($pdf_url . serialize($options));
        
        // Process PDF and return HTML
        ob_start();
        include PDFFB_PLUGIN_DIR . 'templates/viewer-template.php';
        return ob_get_clean();
    }
    
    public static function auto_link_pdfs($content) {
        if (get_option('pdf_flipbook_auto_link')) {
            // Regex to find PDF links and replace with flipbook
            $pattern = '/<a\s[^>]*href=(["\'])([^"\']+\.pdf)\1[^>]*>(.*?)<\/a>/i';
            $content = preg_replace_callback($pattern, array(__CLASS__, 'replace_pdf_link'), $content);
        }
        return $content;
    }
    
    private static function replace_pdf_link($matches) {
        $pdf_url = $matches[2];
        $link_text = $matches[3];
        
        // Get options
        $options = get_option('pdf_flipbook_defaults');
        
        // Return flipbook shortcode or embedded viewer
        return do_shortcode("[pdf_flipbook_link url='{$pdf_url}' text='{$link_text}']");
    }
}