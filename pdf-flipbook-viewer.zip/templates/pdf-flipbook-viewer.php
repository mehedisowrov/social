<?php
/*
Plugin Name: PDF FlipBook Viewer
Description: Embed PDF files as interactive flipbooks with advanced viewing options.
Version: 1.0.0
Author: Your Name
License: GPLv2 or later
Text Domain: pdf-flipbook-viewer
*/

// Security check
defined('ABSPATH') or die('No direct access!');

// Define constants
define('PDFFB_VERSION', '1.0.0');
define('PDFFB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PDFFB_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once PDFFB_PLUGIN_DIR . 'includes/shortcodes.php';
require_once PDFFB_PLUGIN_DIR . 'includes/settings.php';
require_once PDFFB_PLUGIN_DIR . 'includes/pdf-processor.php';

// Initialize plugin
class PDF_FlipBook_Viewer {
    
    public function __construct() {
        // Register hooks
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_menu', array($this, 'create_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Initialize shortcodes
        new PDFFB_Shortcodes();
    }
    
    public function enqueue_assets() {
        // Frontend CSS
        wp_enqueue_style('pdf-flipbook-viewer', PDFFB_PLUGIN_URL . 'assets/css/viewer.css', array(), PDFFB_VERSION);
        
        // Frontend JS
        wp_enqueue_script('pdfjs', PDFFB_PLUGIN_URL . 'assets/js/pdf.min.js', array(), '2.12.313', true);
        wp_enqueue_script('pdf-flipbook-viewer', PDFFB_PLUGIN_URL . 'assets/js/viewer.js', array('jquery', 'pdfjs'), PDFFB_VERSION, true);
        
        // Localize script for AJAX and translations
        wp_localize_script('pdf-flipbook-viewer', 'pdfFlipbookVars', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('pdf-flipbook-nonce')
        ));
    }
    
    public function create_admin_menu() {
        add_options_page(
            'PDF FlipBook Settings',
            'PDF FlipBook',
            'manage_options',
            'pdf-flipbook-settings',
            array($this, 'render_settings_page')
        );
    }
    
    public function register_settings() {
        // Register all settings
        register_setting('pdf_flipbook_options', 'pdf_flipbook_defaults');
    }
    
    public function render_settings_page() {
        include PDFFB_PLUGIN_DIR . 'templates/settings-page.php';
    }
}

// Initialize the plugin
new PDF_FlipBook_Viewer();