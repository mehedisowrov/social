<div class="wrap">
    <h1>PDF FlipBook Viewer Settings</h1>
    
    <form method="post" action="options.php">
        <?php settings_fields('pdf_flipbook_options'); ?>
        <?php $options = get_option('pdf_flipbook_defaults'); ?>
        
        <h2>General Settings</h2>
        <table class="form-table">
            <tr>
                <th>Auto-link PDFs</th>
                <td>
                    <label>
                        <input type="checkbox" name="pdf_flipbook_defaults[auto_link]" value="1" <?php checked(1, $options['auto_link'] ?? 0); ?>>
                        Automatically convert PDF links to flipbook viewer
                    </label>
                </td>
            </tr>
            
            <tr>
                <th>Default Toolbar Position</th>
                <td>
                    <select name="pdf_flipbook_defaults[toolbar_position]">
                        <option value="top" <?php selected('top', $options['toolbar_position'] ?? 'top'); ?>>Top</option>
                        <option value="bottom" <?php selected('bottom', $options['toolbar_position'] ?? 'top'); ?>>Bottom</option>
                        <option value="left" <?php selected('left', $options['toolbar_position'] ?? 'top'); ?>>Left</option>
                        <option value="right" <?php selected('right', $options['toolbar_position'] ?? 'top'); ?>>Right</option>
                    </select>
                </td>
            </tr>
            
            <!-- Add more settings fields as needed -->
        </table>
        
        <h2>FlipBook Options</h2>
        <table class="form-table">
            <tr>
                <th>Flip Sound</th>
                <td>
                    <label>
                        <input type="checkbox" name="pdf_flipbook_defaults[flip_sound]" value="1" <?php checked(1, $options['flip_sound'] ?? 1); ?>>
                        Enable page turn sound effect
                    </label>
                </td>
            </tr>
            
            <!-- Add more flipbook-specific options -->
        </table>
        
        <?php submit_button(); ?>
    </form>
    
    <h2>Shortcode Examples</h2>
    <p><code>[pdf_flipbook url="http://example.com/document.pdf"]</code></p>
    <p><code>[pdf_flipbook_link url="http://example.com/document.pdf" text="View Document"]</code></p>
    <p><code>[pdf_flipbook_embed url="http://example.com/document.pdf" width="800px" height="600px"]</code></p>
</div>