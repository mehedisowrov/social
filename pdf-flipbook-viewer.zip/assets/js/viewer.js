jQuery(document).ready(function($) {
    
    // Initialize PDF.js
    pdfjsLib.GlobalWorkerOptions.workerSrc = pdfFlipbookVars.pluginUrl + 'assets/js/pdf.worker.min.js';
    
    // Handle flipbook links
    $('body').on('click', '.pdf-flipbook-link', function(e) {
        e.preventDefault();
        var pdfUrl = $(this).attr('href');
        openFlipbookModal(pdfUrl);
    });
    
    // Handle auto-linked PDFs
    $('a[href$=".pdf"]').not('.pdf-flipbook-link').each(function() {
        if (pdfFlipbookVars.autoLinkEnabled) {
            $(this).addClass('pdf-flipbook-link').attr('data-flipbook', '1');
        }
    });
    
    function openFlipbookModal(pdfUrl) {
        // Create modal with loading state
        var modalHtml = '<div class="pdf-flipbook-modal">' +
                        '<div class="pdf-flipbook-container">' +
                        '<div class="pdf-flipbook-toolbar"></div>' +
                        '<div class="pdf-flipbook-viewer"></div>' +
                        '</div></div>';
        
        $('body').append(modalHtml);
        
        // Load PDF
        loadPDF(pdfUrl);
    }
    
    function loadPDF(url) {
        // Use PDF.js to load and render the PDF
        var loadingTask = pdfjsLib.getDocument(url);
        
        loadingTask.promise.then(function(pdf) {
            // PDF loaded
            renderPDFPages(pdf);
        }, function(error) {
            // Error handling
            console.error('PDF loading error:', error);
        });
    }
    
    function renderPDFPages(pdf) {
        // Implementation for rendering pages with flipbook effect
    }
});